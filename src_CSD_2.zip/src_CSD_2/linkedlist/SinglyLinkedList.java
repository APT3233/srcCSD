package linkedlist;

/**
 * Question: How to build a singly linked list with operations:
 * - search
 * - insert at head
 * - insert at tail
 * - insert at k-th position
 * - traverse
 * - reverse
 * 
 * Example usage:
 * SinglyLinkedList<Integer> list = new SinglyLinkedList<>();
 * list.insertAtHead(1);
 * list.insertAtTail(2);
 * list.insertAt(1, 3);
 * list.traverse(); // 1 -> 3 -> 2
 * list.reverse();
 * list.traverse(); // 2 -> 3 -> 1
 */
public class SinglyLinkedList<T> {
    private class Node {
        T data;
        Node next;
        
        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
    
    private Node head;
    private int size;
    
    public SinglyLinkedList() {
        head = null;
        size = 0;
    }
    
    public void insertAtHead(T data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
        size++;
    }
    
    public void insertAtTail(T data) {
        if (head == null) {
            insertAtHead(data);
            return;
        }
        
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = new Node(data);
        size++;
    }
    
    public void insertAt(int position, T data) {
        if (position < 0 || position > size) {
            throw new IndexOutOfBoundsException();
        }
        
        if (position == 0) {
            insertAtHead(data);
            return;
        }
        
        Node current = head;
        for (int i = 0; i < position - 1; i++) {
            current = current.next;
        }
        
        Node newNode = new Node(data);
        newNode.next = current.next;
        current.next = newNode;
        size++;
    }
    
    public Node search(T data) {
        Node current = head;
        while (current != null) {
            if (current.data.equals(data)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }
    
    public void traverse() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    
    public void reverse() {
        Node prev = null;
        Node current = head;
        Node next = null;
        
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        
        head = prev;
    }
}