package linkedlist;

/**
 * Question: Build a double circular linked list (DCL) and use it to solve Josephus problem
 * 
 * Example usage:
 * DoubleCircularLinkedList<Integer> dcl = new DoubleCircularLinkedList<>();
 * dcl.insert(1);
 * dcl.insert(2);
 * dcl.insert(3);
 * dcl.solveJosephus(3); // Solves Josephus problem with skip of 3
 */
public class DoubleCircularLinkedList<T> {
    private class Node {
        T data;
        Node next;
        Node prev;
        
        Node(T data) {
            this.data = data;
        }
    }
    
    private Node head;
    private int size;
    
    public void insert(T data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
            head.prev = head;
        } else {
            Node last = head.prev;
            last.next = newNode;
            newNode.prev = last;
            newNode.next = head;
            head.prev = newNode;
        }
        size++;
    }
    
    public void delete(T data) {
        if (head == null) return;
        
        Node current = head;
        do {
            if (current.data.equals(data)) {
                if (size == 1) {
                    head = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                    if (current == head) {
                        head = current.next;
                    }
                }
                size--;
                return;
            }
            current = current.next;
        } while (current != head);
    }
    
    public void solveJosephus(int k) {
        if (head == null) return;
        
        Node current = head;
        while (size > 1) {
            for (int i = 0; i < k - 1; i++) {
                current = current.next;
            }
            Node temp = current.next;
            delete(current.data);
            current = temp;
        }
        System.out.println("Last survivor: " + head.data);
    }
    
    public void display() {
        if (head == null) return;
        
        Node current = head;
        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != head);
        System.out.println(" (back to head)");
    }
}