package combinatorics;

import java.util.*;

/**
 * Question: Generate all permutations of a string/array with and without recursion
 * 
 * Example usage:
 * Permutations.generatePermutations("ABC");
 * Permutations.generatePermutationsIterative("ABC");
 */
public class Permutations {
    // Recursive approach
    public static void generatePermutations(String str) {
        System.out.println("Generating permutations recursively for: " + str);
        generatePermutationsUtil(str.toCharArray(), 0);
    }
    
    private static void generatePermutationsUtil(char[] arr, int pos) {
        if (pos == arr.length) {
            System.out.println(String.valueOf(arr));
            return;
        }
        
        for (int i = pos; i < arr.length; i++) {
            swap(arr, pos, i);
            generatePermutationsUtil(arr, pos + 1);
            swap(arr, pos, i); // backtrack
        }
    }
    
    // Iterative approach using Heap's algorithm
    public static void generatePermutationsIterative(String str) {
        System.out.println("Generating permutations iteratively for: " + str);
        char[] arr = str.toCharArray();
        int[] c = new int[arr.length];
        
        System.out.println(String.valueOf(arr));
        int i = 0;
        while (i < arr.length) {
            if (c[i] < i) {
                if (i % 2 == 0) {
                    swap(arr, 0, i);
                } else {
                    swap(arr, c[i], i);
                }
                System.out.println(String.valueOf(arr));
                c[i]++;
                i = 0;
            } else {
                c[i] = 0;
                i++;
            }
        }
    }
    
    private static void swap(char[] arr, int i, int j) {
        char temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    
    public static void main(String[] args) {
        String str = "ABC";
        System.out.println("Recursive approach:");
        generatePermutations(str);
        
        System.out.println("\nIterative approach:");
        generatePermutationsIterative(str);
    }
}