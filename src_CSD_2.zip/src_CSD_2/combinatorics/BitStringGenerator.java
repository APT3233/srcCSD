package combinatorics;

/**
 * Question: To enumerate bit strings, combinators and permutations with/without recursion
 * 
 * Example usage:
 * BitStringGenerator.generateBitStrings(3);
 * BitStringGenerator.generateBitStringsIterative(3);
 */
public class BitStringGenerator {
    // Recursive approach
    public static void generateBitStrings(int n) {
        System.out.println("Generating bit strings recursively for n = " + n);
        generateBitStringsUtil(n, new int[n], 0);
    }
    
    private static void generateBitStringsUtil(int n, int[] arr, int i) {
        if (i == n) {
            printBitString(arr);
            return;
        }
        
        arr[i] = 0;
        generateBitStringsUtil(n, arr, i + 1);
        arr[i] = 1;
        generateBitStringsUtil(n, arr, i + 1);
    }
    
    // Iterative approach using binary counting
    public static void generateBitStringsIterative(int n) {
        System.out.println("Generating bit strings iteratively for n = " + n);
        int total = 1 << n; // 2^n
        
        for (int i = 0; i < total; i++) {
            for (int j = n - 1; j >= 0; j--) {
                System.out.print((i >> j) & 1);
            }
            System.out.println();
        }
    }
    
    private static void printBitString(int[] arr) {
        for (int bit : arr) {
            System.out.print(bit);
        }
        System.out.println();
    }
    
    public static void main(String[] args) {
        int n = 3;
        System.out.println("Recursive approach:");
        generateBitStrings(n);
        
        System.out.println("\nIterative approach:");
        generateBitStringsIterative(n);
    }
}