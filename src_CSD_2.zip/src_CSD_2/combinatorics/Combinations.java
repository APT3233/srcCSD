package combinatorics;

import java.util.*;

/**
 * Question: Generate all combinations of size k from n elements
 * 
 * Example usage:
 * Combinations.generateCombinations(new int[]{1, 2, 3, 4}, 2);
 * Combinations.generateCombinationsIterative(new int[]{1, 2, 3, 4}, 2);
 */
public class Combinations {
    // Recursive approach
    public static void generateCombinations(int[] arr, int k) {
        System.out.println("Generating combinations recursively for k = " + k);
        generateCombinationsUtil(arr, k, 0, new ArrayList<>());
    }
    
    private static void generateCombinationsUtil(int[] arr, int k, int start, List<Integer> current) {
        if (current.size() == k) {
            System.out.println(current);
            return;
        }
        
        for (int i = start; i < arr.length; i++) {
            current.add(arr[i]);
            generateCombinationsUtil(arr, k, i + 1, current);
            current.remove(current.size() - 1);
        }
    }
    
    // Iterative approach using bit manipulation
    public static void generateCombinationsIterative(int[] arr, int k) {
        System.out.println("Generating combinations iteratively for k = " + k);
        int n = arr.length;
        int combinations = 1 << n;
        
        for (int i = 0; i < combinations; i++) {
            if (Integer.bitCount(i) == k) {
                List<Integer> combination = new ArrayList<>();
                for (int j = 0; j < n; j++) {
                    if ((i & (1 << j)) != 0) {
                        combination.add(arr[j]);
                    }
                }
                System.out.println(combination);
            }
        }
    }
    
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4};
        int k = 2;
        
        System.out.println("Recursive approach:");
        generateCombinations(arr, k);
        
        System.out.println("\nIterative approach:");
        generateCombinationsIterative(arr, k);
    }
}