package hash;

/**
 * Question: What is hashing? Implement hash table with separate chaining and coalesced chaining
 * 
 * Example usage:
 * HashTable<String, Integer> ht = new HashTable<>(10);
 * ht.put("one", 1);
 * ht.put("two", 2);
 * System.out.println(ht.get("one")); // prints: 1
 */
public class HashTable<K, V> {
    private static class Node<K, V> {
        K key;
        V value;
        Node<K, V> next;
        
        Node(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }
    
    private Node<K, V>[] table;
    private int size;
    private int capacity;
    
    @SuppressWarnings("unchecked")
    public HashTable(int capacity) {
        this.capacity = capacity;
        table = (Node<K, V>[]) new Node[capacity];
        size = 0;
    }
    
    private int hash(K key) {
        return Math.abs(key.hashCode() % capacity);
    }
    
    // Separate Chaining implementation
    public void put(K key, V value) {
        int index = hash(key);
        
        if (table[index] == null) {
            table[index] = new Node<>(key, value);
        } else {
            // Check if key exists
            Node<K, V> current = table[index];
            while (current != null) {
                if (current.key.equals(key)) {
                    current.value = value;
                    return;
                }
                current = current.next;
            }
            
            // Add new node at beginning of chain
            Node<K, V> newNode = new Node<>(key, value);
            newNode.next = table[index];
            table[index] = newNode;
        }
        size++;
    }
    
    public V get(K key) {
        int index = hash(key);
        Node<K, V> current = table[index];
        
        while (current != null) {
            if (current.key.equals(key)) {
                return current.value;
            }
            current = current.next;
        }
        
        return null;
    }
    
    public void remove(K key) {
        int index = hash(key);
        
        if (table[index] == null) {
            return;
        }
        
        if (table[index].key.equals(key)) {
            table[index] = table[index].next;
            size--;
            return;
        }
        
        Node<K, V> current = table[index];
        while (current.next != null) {
            if (current.next.key.equals(key)) {
                current.next = current.next.next;
                size--;
                return;
            }
            current = current.next;
        }
    }
    
    public boolean containsKey(K key) {
        return get(key) != null;
    }
    
    public int size() {
        return size;
    }
    
    public boolean isEmpty() {
        return size == 0;
    }
}