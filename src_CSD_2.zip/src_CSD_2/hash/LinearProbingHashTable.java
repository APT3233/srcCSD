package hash;

/**
 * Question: Implement hash table with opening addressing: linear and quadratic probing
 * 
 * Example usage:
 * LinearProbingHashTable<String, Integer> ht = new LinearProbingHashTable<>(10);
 * ht.put("one", 1);
 * ht.put("two", 2);
 * System.out.println(ht.get("one")); // prints: 1
 */
public class LinearProbingHashTable<K, V> {
    private static class Entry<K, V> {
        K key;
        V value;
        boolean isDeleted;
        
        Entry(K key, V value) {
            this.key = key;
            this.value = value;
            this.isDeleted = false;
        }
    }
    
    private Entry<K, V>[] table;
    private int size;
    private int capacity;
    private static final double LOAD_FACTOR_THRESHOLD = 0.75;
    
    @SuppressWarnings("unchecked")
    public LinearProbingHashTable(int capacity) {
        this.capacity = capacity;
        table = (Entry<K, V>[]) new Entry[capacity];
        size = 0;
    }
    
    private int hash(K key) {
        return Math.abs(key.hashCode() % capacity);
    }
    
    public void put(K key, V value) {
        if ((double) size / capacity >= LOAD_FACTOR_THRESHOLD) {
            resize();
        }
        
        int index = hash(key);
        int i = 0;
        
        while (i < capacity) {
            int probeIndex = (index + i) % capacity; // Linear probing
            
            if (table[probeIndex] == null || table[probeIndex].isDeleted) {
                table[probeIndex] = new Entry<>(key, value);
                size++;
                return;
            }
            
            if (table[probeIndex].key.equals(key)) {
                table[probeIndex].value = value;
                return;
            }
            
            i++;
        }
        
        throw new IllegalStateException("Hash table is full");
    }
    
    public V get(K key) {
        int index = hash(key);
        int i = 0;
        
        while (i < capacity) {
            int probeIndex = (index + i) % capacity;
            
            if (table[probeIndex] == null) {
                return null;
            }
            
            if (!table[probeIndex].isDeleted && table[probeIndex].key.equals(key)) {
                return table[probeIndex].value;
            }
            
            i++;
        }
        
        return null;
    }
    
    public void remove(K key) {
        int index = hash(key);
        int i = 0;
        
        while (i < capacity) {
            int probeIndex = (index + i) % capacity;
            
            if (table[probeIndex] == null) {
                return;
            }
            
            if (!table[probeIndex].isDeleted && table[probeIndex].key.equals(key)) {
                table[probeIndex].isDeleted = true;
                size--;
                return;
            }
            
            i++;
        }
    }
    
    @SuppressWarnings("unchecked")
    private void resize() {
        int oldCapacity = capacity;
        Entry<K, V>[] oldTable = table;
        
        capacity = capacity * 2;
        table = (Entry<K, V>[]) new Entry[capacity];
        size = 0;
        
        for (int i = 0; i < oldCapacity; i++) {
            if (oldTable[i] != null && !oldTable[i].isDeleted) {
                put(oldTable[i].key, oldTable[i].value);
            }
        }
    }
    
    public boolean containsKey(K key) {
        return get(key) != null;
    }
    
    public int size() {
        return size;
    }
    
    public boolean isEmpty() {
        return size == 0;
    }
}