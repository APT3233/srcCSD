package sorting;

/**
 * Question: Can you implement Merge sort with/without using recursion?
 * 
 * Example usage:
 * int[] arr = {64, 34, 25, 12, 22, 11, 90};
 * MergeSort.sortRecursive(arr);  // Using recursion
 * MergeSort.sortIterative(arr);  // Without recursion
 */
public class MergeSort {
    // Recursive implementation
    public static void sortRecursive(int[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            int[] left = new int[mid];
            int[] right = new int[arr.length - mid];
            
            System.arraycopy(arr, 0, left, 0, mid);
            System.arraycopy(arr, mid, right, 0, arr.length - mid);
            
            sortRecursive(left);
            sortRecursive(right);
            merge(arr, left, right);
        }
    }
    
    // Iterative implementation
    public static void sortIterative(int[] arr) {
        int n = arr.length;
        for (int size = 1; size < n; size *= 2) {
            for (int left = 0; left < n - 1; left += 2 * size) {
                int mid = Math.min(left + size - 1, n - 1);
                int right = Math.min(left + 2 * size - 1, n - 1);
                mergeIterative(arr, left, mid, right);
            }
        }
    }
    
    private static void merge(int[] arr, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;
        
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }
        
        while (i < left.length) {
            arr[k++] = left[i++];
        }
        
        while (j < right.length) {
            arr[k++] = right[j++];
        }
    }
    
    private static void mergeIterative(int[] arr, int left, int mid, int right) {
        int[] temp = new int[right - left + 1];
        int i = left, j = mid + 1, k = 0;
        
        while (i <= mid && j <= right) {
            if (arr[i] <= arr[j]) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
            }
        }
        
        while (i <= mid) {
            temp[k++] = arr[i++];
        }
        
        while (j <= right) {
            temp[k++] = arr[j++];
        }
        
        System.arraycopy(temp, 0, arr, left, temp.length);
    }
    
    public static void main(String[] args) {
        // Test recursive implementation
        int[] arr1 = {64, 34, 25, 12, 22, 11, 90};
        System.out.println("Original array:");
        printArray(arr1);
        
        sortRecursive(arr1);
        System.out.println("\nSorted array (recursive):");
        printArray(arr1);
        
        // Test iterative implementation
        int[] arr2 = {64, 34, 25, 12, 22, 11, 90};
        sortIterative(arr2);
        System.out.println("\nSorted array (iterative):");
        printArray(arr2);
    }
    
    private static void printArray(int[] arr) {
        for (int value : arr) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}