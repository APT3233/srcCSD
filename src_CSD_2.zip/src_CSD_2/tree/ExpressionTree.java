package tree;

import java.util.Stack;

/**
 * Question: Comprise an expression tree from infix and postfix traversals using recursion/loop?
 * 
 * Example usage:
 * String postfix = "ab+c*";
 * ExpressionTree tree = new ExpressionTree();
 * Node root = tree.constructFromPostfix(postfix);
 * tree.inorderTraversal(root); // prints: (a+b)*c
 */
public class ExpressionTree {
    class Node {
        char data;
        Node left, right;
        
        Node(char data) {
            this.data = data;
            left = right = null;
        }
    }
    
    public Node constructFromPostfix(String postfix) {
        Stack<Node> st = new Stack<>();
        
        for (char c : postfix.toCharArray()) {
            if (!isOperator(c)) {
                st.push(new Node(c));
            } else {
                Node right = st.pop();
                Node left = st.pop();
                Node node = new Node(c);
                node.left = left;
                node.right = right;
                st.push(node);
            }
        }
        return st.peek();
    }
    
    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }
    
    public void inorderTraversal(Node root) {
        if (root != null) {
            if (isOperator(root.data)) {
                System.out.print("(");
            }
            inorderTraversal(root.left);
            System.out.print(root.data);
            inorderTraversal(root.right);
            if (isOperator(root.data)) {
                System.out.print(")");
            }
        }
    }
    
    public static void main(String[] args) {
        ExpressionTree tree = new ExpressionTree();
        String postfix = "ab+c*";
        System.out.println("Postfix expression: " + postfix);
        
        Node root = tree.constructFromPostfix(postfix);
        System.out.print("Infix expression: ");
        tree.inorderTraversal(root);
        System.out.println();
    }
}