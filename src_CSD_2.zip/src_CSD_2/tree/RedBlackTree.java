package tree;

/**
 * Question: Implement a Red-Black Tree with operations:
 * - insert
 * - delete
 * - search
 * - traversal
 * 
 * Example usage:
 * RedBlackTree<Integer> rbt = new RedBlackTree<>();
 * rbt.insert(7);
 * rbt.insert(3);
 * rbt.insert(18);
 */
public class RedBlackTree<T extends Comparable<T>> {
    private static final boolean RED = true;
    private static final boolean BLACK = false;
    
    private class Node {
        T data;
        Node left, right, parent;
        boolean color;
        
        Node(T data) {
            this.data = data;
            this.color = RED;
        }
    }
    
    private Node root;
    
    public void insert(T data) {
        Node node = new Node(data);
        root = insert(root, node);
        fixViolation(node);
    }
    
    private Node insert(Node root, Node node) {
        if (root == null) return node;
        
        if (node.data.compareTo(root.data) < 0) {
            root.left = insert(root.left, node);
            root.left.parent = root;
        } else if (node.data.compareTo(root.data) > 0) {
            root.right = insert(root.right, node);
            root.right.parent = root;
        }
        
        return root;
    }
    
    private void fixViolation(Node node) {
        Node parent = null;
        Node grandParent = null;
        
        while (node != root && node.color == RED && node.parent.color == RED) {
            parent = node.parent;
            grandParent = parent.parent;
            
            if (parent == grandParent.left) {
                Node uncle = grandParent.right;
                
                if (uncle != null && uncle.color == RED) {
                    grandParent.color = RED;
                    parent.color = BLACK;
                    uncle.color = BLACK;
                    node = grandParent;
                } else {
                    if (node == parent.right) {
                        rotateLeft(parent);
                        node = parent;
                        parent = node.parent;
                    }
                    rotateRight(grandParent);
                    boolean tempColor = parent.color;
                    parent.color = grandParent.color;
                    grandParent.color = tempColor;
                    node = parent;
                }
            } else {
                Node uncle = grandParent.left;
                
                if (uncle != null && uncle.color == RED) {
                    grandParent.color = RED;
                    parent.color = BLACK;
                    uncle.color = BLACK;
                    node = grandParent;
                } else {
                    if (node == parent.left) {
                        rotateRight(parent);
                        node = parent;
                        parent = node.parent;
                    }
                    rotateLeft(grandParent);
                    boolean tempColor = parent.color;
                    parent.color = grandParent.color;
                    grandParent.color = tempColor;
                    node = parent;
                }
            }
        }
        
        root.color = BLACK;
    }
    
    private void rotateLeft(Node node) {
        Node rightChild = node.right;
        node.right = rightChild.left;
        
        if (node.right != null) {
            node.right.parent = node;
        }
        
        rightChild.parent = node.parent;
        
        if (node.parent == null) {
            root = rightChild;
        } else if (node == node.parent.left) {
            node.parent.left = rightChild;
        } else {
            node.parent.right = rightChild;
        }
        
        rightChild.left = node;
        node.parent = rightChild;
    }
    
    private void rotateRight(Node node) {
        Node leftChild = node.left;
        node.left = leftChild.right;
        
        if (node.left != null) {
            node.left.parent = node;
        }
        
        leftChild.parent = node.parent;
        
        if (node.parent == null) {
            root = leftChild;
        } else if (node == node.parent.left) {
            node.parent.left = leftChild;
        } else {
            node.parent.right = leftChild;
        }
        
        leftChild.right = node;
        node.parent = leftChild;
    }
    
    public void inorderTraversal() {
        inorderTraversalUtil(root);
        System.out.println();
    }
    
    private void inorderTraversalUtil(Node node) {
        if (node != null) {
            inorderTraversalUtil(node.left);
            System.out.print(node.data + "(" + (node.color ? "R" : "B") + ") ");
            inorderTraversalUtil(node.right);
        }
    }
}