package tree;

/**
 * Question: Implement a B-Tree with operations:
 * - insert
 * - search
 * - traverse
 * 
 * Example usage:
 * BTree<Integer> btree = new BTree<>(3);
 * btree.insert(10);
 * btree.insert(20);
 * btree.insert(5);
 */
public class BTree<T extends Comparable<T>> {
    private class Node {
        T[] keys;
        Node[] children;
        int n;
        boolean leaf;
        
        @SuppressWarnings("unchecked")
        Node(int t, boolean leaf) {
            this.leaf = leaf;
            keys = (T[]) new Comparable[2*t - 1];
            children = new Node[2*t];
            n = 0;
        }
    }
    
    private Node root;
    private final int t;  // Minimum degree
    
    public BTree(int t) {
        this.t = t;
        root = new Node(t, true);
    }
    
    public void insert(T key) {
        Node r = root;
        
        if (r.n == 2*t - 1) {
            Node s = new Node(t, false);
            root = s;
            s.children[0] = r;
            splitChild(s, 0, r);
            insertNonFull(s, key);
        } else {
            insertNonFull(r, key);
        }
    }
    
    private void insertNonFull(Node x, T key) {
        int i = x.n - 1;
        
        if (x.leaf) {
            while (i >= 0 && key.compareTo(x.keys[i]) < 0) {
                x.keys[i + 1] = x.keys[i];
                i--;
            }
            x.keys[i + 1] = key;
            x.n++;
        } else {
            while (i >= 0 && key.compareTo(x.keys[i]) < 0) {
                i--;
            }
            i++;
            
            if (x.children[i].n == 2*t - 1) {
                splitChild(x, i, x.children[i]);
                if (key.compareTo(x.keys[i]) > 0) {
                    i++;
                }
            }
            insertNonFull(x.children[i], key);
        }
    }
    
    private void splitChild(Node x, int i, Node y) {
        Node z = new Node(t, y.leaf);
        z.n = t - 1;
        
        for (int j = 0; j < t-1; j++) {
            z.keys[j] = y.keys[j + t];
        }
        
        if (!y.leaf) {
            for (int j = 0; j < t; j++) {
                z.children[j] = y.children[j + t];
            }
        }
        
        y.n = t - 1;
        
        for (int j = x.n; j >= i+1; j--) {
            x.children[j + 1] = x.children[j];
        }
        
        x.children[i + 1] = z;
        
        for (int j = x.n-1; j >= i; j--) {
            x.keys[j + 1] = x.keys[j];
        }
        
        x.keys[i] = y.keys[t - 1];
        x.n++;
    }
    
    public void traverse() {
        if (root != null) {
            traverse(root);
        }
        System.out.println();
    }
    
    private void traverse(Node x) {
        int i;
        for (i = 0; i < x.n; i++) {
            if (!x.leaf) {
                traverse(x.children[i]);
            }
            System.out.print(x.keys[i] + " ");
        }
        
        if (!x.leaf) {
            traverse(x.children[i]);
        }
    }
    
    public Node search(T key) {
        return root == null ? null : search(root, key);
    }
    
    private Node search(Node x, T key) {
        int i = 0;
        while (i < x.n && key.compareTo(x.keys[i]) > 0) {
            i++;
        }
        
        if (i < x.n && key.compareTo(x.keys[i]) == 0) {
            return x;
        }
        
        if (x.leaf) {
            return null;
        }
        
        return search(x.children[i], key);
    }
}