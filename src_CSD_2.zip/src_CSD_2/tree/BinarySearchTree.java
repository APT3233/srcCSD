package tree;

/**
 * Question: How to build a BST with operations:
 * - search
 * - insert
 * - delete
 * - traversals (in-order, pre-order, post-order)
 * 
 * Example usage:
 * BinarySearchTree<Integer> bst = new BinarySearchTree<>();
 * bst.insert(5);
 * bst.insert(3);
 * bst.insert(7);
 * bst.inorderTraversal(); // prints: 3 5 7
 * bst.search(3); // returns true
 * bst.delete(5);
 */
public class BinarySearchTree<T extends Comparable<T>> {
    private class Node {
        T data;
        Node left;
        Node right;
        
        Node(T data) {
            this.data = data;
            left = right = null;
        }
    }
    
    private Node root;
    
    public void insert(T data) {
        root = insertRec(root, data);
    }
    
    private Node insertRec(Node root, T data) {
        if (root == null) {
            return new Node(data);
        }
        
        if (data.compareTo(root.data) < 0) {
            root.left = insertRec(root.left, data);
        } else if (data.compareTo(root.data) > 0) {
            root.right = insertRec(root.right, data);
        }
        
        return root;
    }
    
    public boolean search(T data) {
        return searchRec(root, data);
    }
    
    private boolean searchRec(Node root, T data) {
        if (root == null || root.data.equals(data)) {
            return root != null;
        }
        
        if (data.compareTo(root.data) < 0) {
            return searchRec(root.left, data);
        }
        
        return searchRec(root.right, data);
    }
    
    public void delete(T data) {
        root = deleteRec(root, data);
    }
    
    private Node deleteRec(Node root, T data) {
        if (root == null) {
            return null;
        }
        
        if (data.compareTo(root.data) < 0) {
            root.left = deleteRec(root.left, data);
        } else if (data.compareTo(root.data) > 0) {
            root.right = deleteRec(root.right, data);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            
            root.data = minValue(root.right);
            root.right = deleteRec(root.right, root.data);
        }
        
        return root;
    }
    
    private T minValue(Node root) {
        T minv = root.data;
        while (root.left != null) {
            minv = root.left.data;
            root = root.left;
        }
        return minv;
    }
    
    public void inorderTraversal() {
        inorderRec(root);
        System.out.println();
    }
    
    private void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.data + " ");
            inorderRec(root.right);
        }
    }
    
    public void preorderTraversal() {
        preorderRec(root);
        System.out.println();
    }
    
    private void preorderRec(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorderRec(root.left);
            preorderRec(root.right);
        }
    }
    
    public void postorderTraversal() {
        postorderRec(root);
        System.out.println();
    }
    
    private void postorderRec(Node root) {
        if (root != null) {
            postorderRec(root.left);
            postorderRec(root.right);
            System.out.print(root.data + " ");
        }
    }
}