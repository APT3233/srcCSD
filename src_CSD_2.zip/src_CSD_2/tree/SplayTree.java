package tree;

/**
 * Question: Implement a Splay Tree with operations:
 * - insert
 * - search
 * - delete
 * 
 * Example usage:
 * SplayTree<Integer> splayTree = new SplayTree<>();
 * splayTree.insert(10);
 * splayTree.insert(20);
 * splayTree.search(10);  // Brings 10 to root
 */
public class SplayTree<T extends Comparable<T>> {
    private class Node {
        T data;
        Node left, right;
        
        Node(T data) {
            this.data = data;
        }
    }
    
    private Node root;
    
    private Node rightRotate(Node x) {
        Node y = x.left;
        x.left = y.right;
        y.right = x;
        return y;
    }
    
    private Node leftRotate(Node x) {
        Node y = x.right;
        x.right = y.left;
        y.left = x;
        return y;
    }
    
    private Node splay(Node root, T key) {
        if (root == null || root.data.compareTo(key) == 0) {
            return root;
        }
        
        if (root.data.compareTo(key) > 0) {
            if (root.left == null) return root;
            
            if (root.left.data.compareTo(key) > 0) {
                root.left.left = splay(root.left.left, key);
                root = rightRotate(root);
            } else if (root.left.data.compareTo(key) < 0) {
                root.left.right = splay(root.left.right, key);
                if (root.left.right != null) {
                    root.left = leftRotate(root.left);
                }
            }
            
            return (root.left == null) ? root : rightRotate(root);
        } else {
            if (root.right == null) return root;
            
            if (root.right.data.compareTo(key) > 0) {
                root.right.left = splay(root.right.left, key);
                if (root.right.left != null) {
                    root.right = rightRotate(root.right);
                }
            } else if (root.right.data.compareTo(key) < 0) {
                root.right.right = splay(root.right.right, key);
                root = leftRotate(root);
            }
            
            return (root.right == null) ? root : leftRotate(root);
        }
    }
    
    public void insert(T key) {
        if (root == null) {
            root = new Node(key);
            return;
        }
        
        root = splay(root, key);
        
        if (root.data.compareTo(key) == 0) return;
        
        Node newNode = new Node(key);
        if (root.data.compareTo(key) > 0) {
            newNode.right = root;
            newNode.left = root.left;
            root.left = null;
        } else {
            newNode.left = root;
            newNode.right = root.right;
            root.right = null;
        }
        
        root = newNode;
    }
    
    public Node search(T key) {
        root = splay(root, key);
        return root.data.compareTo(key) == 0 ? root : null;
    }
    
    public void delete(T key) {
        if (root == null) return;
        
        root = splay(root, key);
        
        if (root.data.compareTo(key) != 0) return;
        
        if (root.left == null) {
            root = root.right;
        } else {
            Node temp = root.right;
            root = root.left;
            root = splay(root, key);
            root.right = temp;
        }
    }
    
    public void inorderTraversal() {
        inorderTraversal(root);
        System.out.println();
    }
    
    private void inorderTraversal(Node node) {
        if (node != null) {
            inorderTraversal(node.left);
            System.out.print(node.data + " ");
            inorderTraversal(node.right);
        }
    }
}