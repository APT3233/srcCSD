package tree;

import java.util.LinkedList;
import java.util.Queue;

class Worker {
    int key;
    String name;
    int age;

    Worker(int key, String name, int age) {
        this.key = key;
        this.name = name;
        this.age = age;
    }
}

class TreeNode {
    Worker worker;
    TreeNode left, right;

    TreeNode(Worker worker) {
        this.worker = worker;
        this.left = this.right = null;
    }
}

class WorkerBST {
    TreeNode root;

    // Requirement 1: Find the node with given key and keep its parent if possible
    TreeNode findNode(TreeNode node, int key, TreeNode parent) {
        if (node == null || node.worker.key == key) {
            return node;
        }
        parent = node;
        if (key < node.worker.key) {
            return findNode(node.left, key, parent);
        } else {
            return findNode(node.right, key, parent);
        }
    }

    // Requirement 2: Insert a new worker if not already present
    void insert(Worker worker) {
        root = insertRec(root, worker);
    }

    TreeNode insertRec(TreeNode node, Worker worker) {
        if (node == null) {
            node = new TreeNode(worker);
            return node;
        }
        if (worker.key < node.worker.key) {
            node.left = insertRec(node.left, worker);
        } else if (worker.key > node.worker.key) {
            node.right = insertRec(node.right, worker);
        }
        return node;
    }

    // Requirement 3: Output workers in descending order
    void printDescending(TreeNode node) {
        if (node != null) {
            printDescending(node.right);
            System.out.println("Key: " + node.worker.key + ", Name: " + node.worker.name + ", Age: " + node.worker.age);
            printDescending(node.left);
        }
    }

    // Requirement 4: Count workers with age < 25
    int countWorkersUnder25(TreeNode node) {
        if (node == null) {
            return 0;
        }
        int count = 0;
        if (node.worker.age < 25) {
            count = 1;
        }
        return count + countWorkersUnder25(node.left) + countWorkersUnder25(node.right);
    }

    // Requirement 5: Delete the right-most node
    TreeNode deleteRightMost(TreeNode node) {
        if (node.right == null) {
            return node.left;
        }
        node.right = deleteRightMost(node.right);
        return node;
    }

    void deleteRightMostNode() {
        if (root != null) {
            root = deleteRightMost(root);
        }
    }

    // Requirement 6: Determine height using level-order traversal
    int getHeight() {
        if (root == null) {
            return 0;
        }
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(root);
        int height = 0;

        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            height++;
            for (int i = 0; i < levelSize; i++) {
                TreeNode current = queue.poll();
                if (current.left != null) {
                    queue.add(current.left);
                }
                if (current.right != null) {
                    queue.add(current.right);
                }
            }
        }
        return height;
    }

    // Requirement 7: Create a BST with maximum height from a given sequence
    void createMaxHeightBST(int[] keys) {
        root = null;
        for (int key : keys) {
            insert(new Worker(key, "Worker" + key, 30)); // Assuming age 30 for simplicity
        }
    }
}

public class WorkerBSTProject {
    public static void main(String[] args) {
        WorkerBST tree = new WorkerBST();

        // Sample workers
        tree.insert(new Worker(10, "Alice", 24));
        tree.insert(new Worker(20, "Bob", 28));
        tree.insert(new Worker(5, "Charlie", 22));
        tree.insert(new Worker(15, "Diana", 30));
        tree.insert(new Worker(25, "Eve", 23));

        // Requirement 3: Print workers in descending order
        System.out.println("Workers in descending order:");
        tree.printDescending(tree.root);

        // Requirement 4: Count workers under 25
        int countUnder25 = tree.countWorkersUnder25(tree.root);
        System.out.println("Number of workers under 25: " + countUnder25);

        // Requirement 5: Delete right-most node
        tree.deleteRightMostNode();
        System.out.println("After deleting right-most node:");
        tree.printDescending(tree.root);

        // Requirement 6: Get height of the tree
        int height = tree.getHeight();
        System.out.println("Height of the tree: " + height);

        // Requirement 7: Create BST with maximum height
        int[] sequence = {1, 2, 3, 4, 5};
        tree.createMaxHeightBST(sequence);
        System.out.println("BST with maximum height:");
        tree.printDescending(tree.root);
    }
}
