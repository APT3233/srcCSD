package string;

/**
 * Question: How to solve the problem of string matching with two algorithms of Brute-Force and KMP?
 * 
 * Example usage:
 * String text = "AABAACAADAABAAABAA";
 * String pattern = "AABA";
 * StringMatching.bruteForceSearch(text, pattern);
 * StringMatching.KMPSearch(text, pattern);
 */
public class StringMatching {
    // Brute Force Algorithm
    public static void bruteForceSearch(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        
        System.out.println("Brute Force Pattern Matching:");
        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
                System.out.println("Pattern found at index " + i);
            }
        }
    }
    
    // KMP (Knuth-Morris-Pratt) Algorithm
    public static void KMPSearch(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        
        // Create LPS array (Longest Proper Prefix which is also Suffix)
        int[] lps = new int[m];
        computeLPSArray(pattern, lps);
        
        int i = 0; // Index for text
        int j = 0; // Index for pattern
        
        System.out.println("\nKMP Pattern Matching:");
        while (i < n) {
            if (pattern.charAt(j) == text.charAt(i)) {
                i++;
                j++;
            }
            
            if (j == m) {
                System.out.println("Pattern found at index " + (i - j));
                j = lps[j - 1];
            } else if (i < n && pattern.charAt(j) != text.charAt(i)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }
    }
    
    private static void computeLPSArray(String pattern, int[] lps) {
        int len = 0; // Length of previous longest prefix suffix
        int i = 1;
        
        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
    }
    
    public static void main(String[] args) {
        String text = "AABAACAADAABAAABAA";
        String pattern = "AABA";
        
        System.out.println("Text: " + text);
        System.out.println("Pattern: " + pattern + "\n");
        
        bruteForceSearch(text, pattern);
        KMPSearch(text, pattern);
    }
}