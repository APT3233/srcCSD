package string;

/**
 * Question: Implement KMP (Knuth-Morris-Pratt) pattern searching algorithm
 * 
 * Example usage:
 * String txt = "ABABDABACDABABCABAB";
 * String pat = "ABABCABAB";
 * KMP.search(txt, pat);
 */
public class KMP {
    public static void search(String txt, String pat) {
        int M = pat.length();
        int N = txt.length();
        
        // Create lps[] that will hold the longest prefix suffix values for pattern
        int[] lps = new int[M];
        computeLPSArray(pat, lps);
        
        int i = 0; // index for txt[]
        int j = 0; // index for pat[]
        
        while (i < N) {
            if (pat.charAt(j) == txt.charAt(i)) {
                j++;
                i++;
            }
            
            if (j == M) {
                System.out.println("Pattern found at index " + (i - j));
                j = lps[j - 1];
            } else if (i < N && pat.charAt(j) != txt.charAt(i)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }
    }
    
    private static void computeLPSArray(String pat, int[] lps) {
        int len = 0;
        int i = 1;
        lps[0] = 0;
        
        while (i < pat.length()) {
            if (pat.charAt(i) == pat.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = len;
                    i++;
                }
            }
        }
    }
    
    public static void main(String[] args) {
        String txt = "ABABDABACDABABCABAB";
        String pat = "ABABCABAB";
        System.out.println("Text: " + txt);
        System.out.println("Pattern: " + pat);
        search(txt, pat);
    }
}