package stack;

/**
 * Question: How to convert an infix expression to a prefix expression using a stack?
 * 
 * Example:
 * Input: a + b * c
 * Output: +a*bc
 * 
 * Input: (a + b) * c
 * Output: *+abc
 */
public class InfixToPrefix {
    public static String convert(String infix) {
        // First, reverse the infix expression
        StringBuilder input = new StringBuilder(infix).reverse();
        
        // Replace ( with ) and vice versa
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == '(') {
                input.setCharAt(i, ')');
            } else if (input.charAt(i) == ')') {
                input.setCharAt(i, '(');
            }
        }
        
        // Convert to postfix
        String postfix = infixToPostfix(input.toString());
        
        // Reverse the postfix expression
        return new StringBuilder(postfix).reverse().toString();
    }
    
    private static String infixToPostfix(String infix) {
        StringBuilder result = new StringBuilder();
        ArrayStack<Character> stack = new ArrayStack<>(infix.length());
        
        for (char c : infix.toCharArray()) {
            if (Character.isLetterOrDigit(c)) {
                result.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop());
                }
                stack.pop(); // Remove '('
            } else {
                while (!stack.isEmpty() && precedence(c) <= precedence(stack.peek())) {
                    result.append(stack.pop());
                }
                stack.push(c);
            }
        }
        
        while (!stack.isEmpty()) {
            result.append(stack.pop());
        }
        
        return result.toString();
    }
    
    private static int precedence(char operator) {
        switch (operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }
    
    public static void main(String[] args) {
        String infix = "a+b*c";
        System.out.println("Infix: " + infix);
        System.out.println("Prefix: " + convert(infix));
        
        infix = "(a+b)*c";
        System.out.println("\nInfix: " + infix);
        System.out.println("Prefix: " + convert(infix));
    }
}