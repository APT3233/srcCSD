package stack;

/**
 * Question: Implement a stack using array
 * Operations:
 * - push
 * - pop
 * - peek
 * - isEmpty
 * - isFull
 * 
 * Example usage:
 * ArrayStack<Integer> stack = new ArrayStack<>(5);
 * stack.push(1);
 * stack.push(2);
 * stack.pop(); // returns 2
 * stack.peek(); // returns 1
 */
public class ArrayStack<T> {
    private T[] array;
    private int top;
    private int capacity;
    
    @SuppressWarnings("unchecked")
    public ArrayStack(int capacity) {
        this.capacity = capacity;
        array = (T[]) new Object[capacity];
        top = -1;
    }
    
    public void push(T data) {
        if (isFull()) {
            throw new IllegalStateException("Stack is full");
        }
        array[++top] = data;
    }
    
    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return array[top--];
    }
    
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return array[top];
    }
    
    public boolean isEmpty() {
        return top == -1;
    }
    
    public boolean isFull() {
        return top == capacity - 1;
    }
}