package graph;

import java.util.*;

/**
 * Question: Using depth first search (DFS) to check connectivity and breadth first search (BFS) to find spanning tree
 * 
 * Example usage:
 * Graph graph = new Graph(5);
 * graph.addEdge(0, 1);
 * graph.addEdge(0, 2);
 * graph.addEdge(1, 2);
 * graph.addEdge(2, 3);
 * System.out.println("Is connected: " + graph.isConnected());
 * graph.printBFSSpanningTree(0);
 */
public class Graph {
    private int V;
    private List<List<Integer>> adj;
    
    public Graph(int v) {
        V = v;
        adj = new ArrayList<>(v);
        for (int i = 0; i < v; i++) {
            adj.add(new ArrayList<>());
        }
    }
    
    public void addEdge(int v, int w) {
        adj.get(v).add(w);
        adj.get(w).add(v);
    }
    
    private void DFSUtil(int v, boolean[] visited) {
        visited[v] = true;
        for (int n : adj.get(v)) {
            if (!visited[n]) {
                DFSUtil(n, visited);
            }
        }
    }
    
    public boolean isConnected() {
        boolean[] visited = new boolean[V];
        DFSUtil(0, visited);
        
        for (boolean v : visited) {
            if (!v) return false;
        }
        return true;
    }
    
    public void printBFSSpanningTree(int start) {
        boolean[] visited = new boolean[V];
        int[] parent = new int[V];
        Arrays.fill(parent, -1);
        
        Queue<Integer> queue = new LinkedList<>();
        visited[start] = true;
        queue.add(start);
        
        System.out.println("BFS Spanning Tree edges:");
        while (!queue.isEmpty()) {
            int v = queue.poll();
            for (int n : adj.get(v)) {
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                    parent[n] = v;
                    System.out.println(v + " - " + n);
                }
            }
        }
    }
}