package graph;

import java.util.*;

/**
 * Question: Find strongly connected components in a directed graph using Tarjan's algorithm
 * 
 * Example usage:
 * TarjanSCC scc = new TarjanSCC(5);
 * scc.addEdge(1, 0);
 * scc.addEdge(0, 2);
 * scc.findSCCs();
 */
public class TarjanSCC {
    private int V;
    private List<List<Integer>> adj;
    private int[] disc;
    private int[] low;
    private boolean[] stackMember;
    private Stack<Integer> stack;
    private int time;
    
    public TarjanSCC(int v) {
        V = v;
        adj = new ArrayList<>(V);
        for (int i = 0; i < V; i++) {
            adj.add(new ArrayList<>());
        }
        disc = new int[V];
        low = new int[V];
        stackMember = new boolean[V];
        stack = new Stack<>();
        time = 0;
    }
    
    public void addEdge(int v, int w) {
        adj.get(v).add(w);
    }
    
    public void findSCCs() {
        Arrays.fill(disc, -1);
        Arrays.fill(low, -1);
        Arrays.fill(stackMember, false);
        
        for (int i = 0; i < V; i++) {
            if (disc[i] == -1) {
                SCCUtil(i);
            }
        }
    }
    
    private void SCCUtil(int u) {
        disc[u] = low[u] = ++time;
        stack.push(u);
        stackMember[u] = true;
        
        for (int v : adj.get(u)) {
            if (disc[v] == -1) {
                SCCUtil(v);
                low[u] = Math.min(low[u], low[v]);
            } else if (stackMember[v]) {
                low[u] = Math.min(low[u], disc[v]);
            }
        }
        
        if (low[u] == disc[u]) {
            System.out.print("SCC: ");
            int w;
            do {
                w = stack.pop();
                System.out.print(w + " ");
                stackMember[w] = false;
            } while (w != u);
            System.out.println();
        }
    }
    
    public static void main(String[] args) {
        TarjanSCC scc = new TarjanSCC(5);
        scc.addEdge(1, 0);
        scc.addEdge(0, 2);
        scc.addEdge(2, 1);
        scc.addEdge(0, 3);
        scc.addEdge(3, 4);
        
        System.out.println("Strongly Connected Components:");
        scc.findSCCs();
    }
}