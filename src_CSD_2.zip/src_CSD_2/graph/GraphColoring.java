package graph;

import java.util.*;

/**
 * Question: Color map with minimum number of colors using sequential/backtracking algorithm
 * 
 * Example usage:
 * GraphColoring gc = new GraphColoring(4);
 * gc.addEdge(0, 1);
 * gc.addEdge(1, 2);
 * gc.addEdge(2, 3);
 * gc.colorGraph();
 */
public class GraphColoring {
    private int V;
    private List<List<Integer>> adj;
    private int[] colors;
    
    public GraphColoring(int v) {
        this.V = v;
        adj = new ArrayList<>(v);
        colors = new int[v];
        Arrays.fill(colors, -1);
        
        for (int i = 0; i < v; i++) {
            adj.add(new ArrayList<>());
        }
    }
    
    public void addEdge(int v, int w) {
        adj.get(v).add(w);
        adj.get(w).add(v);
    }
    
    public void colorGraph() {
        // Try sequential coloring first
        if (sequentialColoring()) {
            System.out.println("Graph colored using sequential coloring:");
        } else {
            // If sequential fails, try backtracking
            Arrays.fill(colors, -1);
            if (backtrackingColoring(0)) {
                System.out.println("Graph colored using backtracking:");
            } else {
                System.out.println("No solution exists");
                return;
            }
        }
        printColoring();
    }
    
    private boolean sequentialColoring() {
        for (int v = 0; v < V; v++) {
            boolean[] used = new boolean[V];
            
            // Mark colors used by neighbors
            for (int neighbor : adj.get(v)) {
                if (colors[neighbor] != -1) {
                    used[colors[neighbor]] = true;
                }
            }
            
            // Find first available color
            for (int c = 0; c < V; c++) {
                if (!used[c]) {
                    colors[v] = c;
                    break;
                }
            }
            
            if (colors[v] == -1) return false;
        }
        return true;
    }
    
    private boolean backtrackingColoring(int v) {
        if (v == V) return true;
        
        for (int c = 0; c < V; c++) {
            if (isSafe(v, c)) {
                colors[v] = c;
                if (backtrackingColoring(v + 1)) return true;
                colors[v] = -1;
            }
        }
        return false;
    }
    
    private boolean isSafe(int v, int c) {
        for (int neighbor : adj.get(v)) {
            if (colors[neighbor] == c) return false;
        }
        return true;
    }
    
    private void printColoring() {
        for (int i = 0; i < V; i++) {
            System.out.println("Vertex " + i + " -> Color " + colors[i]);
        }
    }
    
    public static void main(String[] args) {
        GraphColoring gc = new GraphColoring(4);
        gc.addEdge(0, 1);
        gc.addEdge(1, 2);
        gc.addEdge(2, 3);
        gc.colorGraph();
    }
}