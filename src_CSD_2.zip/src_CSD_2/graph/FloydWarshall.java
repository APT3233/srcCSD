package graph;

/**
 * Question: How to find all shortest paths between every pair of vertices?
 * 
 * Example usage:
 * FloydWarshall fw = new FloydWarshall(4);
 * fw.addEdge(0, 1, 5);
 * fw.addEdge(1, 2, 3);
 * fw.findAllPairShortestPaths();
 */
public class FloydWarshall {
    private int V;
    private int[][] dist;
    private final int INF = 99999;
    
    public FloydWarshall(int v) {
        this.V = v;
        dist = new int[V][V];
        
        // Initialize distances
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (i == j) {
                    dist[i][j] = 0;
                } else {
                    dist[i][j] = INF;
                }
            }
        }
    }
    
    public void addEdge(int src, int dest, int weight) {
        dist[src][dest] = weight;
    }
    
    public void findAllPairShortestPaths() {
        // Floyd-Warshall algorithm
        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (dist[i][k] != INF && dist[k][j] != INF 
                        && dist[i][k] + dist[k][j] < dist[i][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                    }
                }
            }
        }
        
        printSolution();
    }
    
    private void printSolution() {
        System.out.println("Shortest distances between all pairs:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (dist[i][j] == INF) {
                    System.out.print("INF ");
                } else {
                    System.out.print(dist[i][j] + " ");
                }
            }
            System.out.println();
        }
    }
}