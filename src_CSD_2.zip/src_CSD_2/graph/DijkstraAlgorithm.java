package graph;

import java.util.*;

/**
 * Question: Using adjacency list and priority queue to find the shortest path between 2 vertices by Dijkstra's algorithm
 * 
 * Example usage:
 * DijkstraAlgorithm graph = new DijkstraAlgorithm(5);
 * graph.addEdge(0, 1, 4);
 * graph.addEdge(0, 2, 1);
 * graph.addEdge(2, 1, 2);
 * graph.addEdge(1, 3, 1);
 * graph.shortestPath(0); // Find shortest paths from vertex 0
 */
public class DijkstraAlgorithm {
    private int V;
    private List<List<Node>> adj;
    
    private class Node implements Comparable<Node> {
        int vertex;
        int weight;
        
        Node(int vertex, int weight) {
            this.vertex = vertex;
            this.weight = weight;
        }
        
        @Override
        public int compareTo(Node other) {
            return Integer.compare(this.weight, other.weight);
        }
    }
    
    public DijkstraAlgorithm(int v) {
        this.V = v;
        adj = new ArrayList<>(v);
        for (int i = 0; i < v; i++) {
            adj.add(new ArrayList<>());
        }
    }
    
    public void addEdge(int src, int dest, int weight) {
        adj.get(src).add(new Node(dest, weight));
        adj.get(dest).add(new Node(src, weight));
    }
    
    public void shortestPath(int src) {
        int[] dist = new int[V];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[src] = 0;
        
        PriorityQueue<Node> pq = new PriorityQueue<>();
        pq.add(new Node(src, 0));
        
        while (!pq.isEmpty()) {
            int u = pq.poll().vertex;
            
            for (Node node : adj.get(u)) {
                int v = node.vertex;
                int weight = node.weight;
                
                if (dist[v] > dist[u] + weight) {
                    dist[v] = dist[u] + weight;
                    pq.add(new Node(v, dist[v]));
                }
            }
        }
        
        System.out.println("Shortest distances from vertex " + src + ":");
        for (int i = 0; i < V; i++) {
            System.out.println(i + ": " + dist[i]);
        }
    }
}