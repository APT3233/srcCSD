package graph;

import java.util.*;

/**
 * Question: Check whether Euler cycle/path exists. Find Hamilton cycle using backtracking
 * 
 * Example usage:
 * CycleDetection cd = new CycleDetection(5);
 * cd.addEdge(0, 1);
 * cd.addEdge(1, 2);
 * System.out.println("Has Euler cycle: " + cd.hasEulerCycle());
 * System.out.println("Has Hamilton cycle: " + cd.findHamiltonCycle());
 */
public class CycleDetection {
    private int V;
    private List<List<Integer>> adj;
    
    public CycleDetection(int v) {
        this.V = v;
        adj = new ArrayList<>(v);
        for (int i = 0; i < v; i++) {
            adj.add(new ArrayList<>());
        }
    }
    
    public void addEdge(int v, int w) {
        adj.get(v).add(w);
        adj.get(w).add(v);
    }
    
    // Check for Euler cycle
    public boolean hasEulerCycle() {
        if (!isConnected()) return false;
        
        // Check if all vertices have even degree
        for (int i = 0; i < V; i++) {
            if (adj.get(i).size() % 2 != 0) {
                return false;
            }
        }
        return true;
    }
    
    // Check for Euler path
    public boolean hasEulerPath() {
        if (!isConnected()) return false;
        
        // Count vertices with odd degree
        int oddDegree = 0;
        for (int i = 0; i < V; i++) {
            if (adj.get(i).size() % 2 != 0) {
                oddDegree++;
            }
        }
        
        // Either all vertices have even degree or exactly two vertices have odd degree
        return oddDegree == 0 || oddDegree == 2;
    }
    
    private boolean isConnected() {
        boolean[] visited = new boolean[V];
        int nonZeroVertex = -1;
        
        // Find a vertex with non-zero degree
        for (int i = 0; i < V; i++) {
            if (adj.get(i).size() > 0) {
                nonZeroVertex = i;
                break;
            }
        }
        
        if (nonZeroVertex == -1) return true;
        
        // DFS from one vertex
        DFS(nonZeroVertex, visited);
        
        // Check if all non-zero degree vertices are visited
        for (int i = 0; i < V; i++) {
            if (!visited[i] && adj.get(i).size() > 0) {
                return false;
            }
        }
        return true;
    }
    
    private void DFS(int v, boolean[] visited) {
        visited[v] = true;
        for (int n : adj.get(v)) {
            if (!visited[n]) {
                DFS(n, visited);
            }
        }
    }
    
    // Hamilton Cycle using backtracking
    public boolean findHamiltonCycle() {
        int[] path = new int[V];
        Arrays.fill(path, -1);
        path[0] = 0;
        
        if (!findHamiltonCycleUtil(path, 1)) {
            System.out.println("No Hamilton cycle exists");
            return false;
        }
        
        printHamiltonCycle(path);
        return true;
    }
    
    private boolean findHamiltonCycleUtil(int[] path, int pos) {
        if (pos == V) {
            // Check if last vertex is connected to first vertex
            return adj.get(path[pos - 1]).contains(path[0]);
        }
        
        for (int v = 1; v < V; v++) {
            if (isSafe(v, path, pos)) {
                path[pos] = v;
                if (findHamiltonCycleUtil(path, pos + 1)) {
                    return true;
                }
                path[pos] = -1;
            }
        }
        return false;
    }
    
    private boolean isSafe(int v, int[] path, int pos) {
        // Check if vertex is adjacent to previous vertex
        if (!adj.get(path[pos - 1]).contains(v)) {
            return false;
        }
        
        // Check if vertex is already included in path
        for (int i = 0; i < pos; i++) {
            if (path[i] == v) {
                return false;
            }
        }
        return true;
    }
    
    private void printHamiltonCycle(int[] path) {
        System.out.println("Hamilton cycle found:");
        for (int i = 0; i < V; i++) {
            System.out.print(path[i] + " -> ");
        }
        System.out.println(path[0]);
    }
    
    public static void main(String[] args) {
        CycleDetection cd = new CycleDetection(5);
        cd.addEdge(0, 1);
        cd.addEdge(1, 2);
        cd.addEdge(2, 3);
        cd.addEdge(3, 4);
        cd.addEdge(4, 0);
        
        System.out.println("Has Euler cycle: " + cd.hasEulerCycle());
        System.out.println("Has Euler path: " + cd.hasEulerPath());
        cd.findHamiltonCycle();
    }
}