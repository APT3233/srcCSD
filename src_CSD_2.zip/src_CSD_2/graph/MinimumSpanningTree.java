package graph;

import java.util.*;

/**
 * Question: How to find minimum spanning tree with Prim's and Kruskal's algorithms?
 * 
 * Example usage:
 * MinimumSpanningTree mst = new MinimumSpanningTree(4);
 * mst.addEdge(0, 1, 10);
 * mst.addEdge(1, 2, 15);
 * mst.primMST();
 * mst.kruskalMST();
 */
public class MinimumSpanningTree {
    private int V;
    private List<Edge> edges;
    private List<List<Node>> adjList;
    
    private class Edge implements Comparable<Edge> {
        int src, dest, weight;
        
        Edge(int src, int dest, int weight) {
            this.src = src;
            this.dest = dest;
            this.weight = weight;
        }
        
        @Override
        public int compareTo(Edge other) {
            return this.weight - other.weight;
        }
    }
    
    private class Node {
        int vertex, weight;
        
        Node(int vertex, int weight) {
            this.vertex = vertex;
            this.weight = weight;
        }
    }
    
    public MinimumSpanningTree(int v) {
        this.V = v;
        edges = new ArrayList<>();
        adjList = new ArrayList<>(V);
        for (int i = 0; i < V; i++) {
            adjList.add(new ArrayList<>());
        }
    }
    
    public void addEdge(int src, int dest, int weight) {
        edges.add(new Edge(src, dest, weight));
        adjList.get(src).add(new Node(dest, weight));
        adjList.get(dest).add(new Node(src, weight));
    }
    
    // Prim's Algorithm
    public void primMST() {
        boolean[] inMST = new boolean[V];
        int[] key = new int[V];
        int[] parent = new int[V];
        Arrays.fill(key, Integer.MAX_VALUE);
        Arrays.fill(parent, -1);
        
        PriorityQueue<Node> pq = new PriorityQueue<>((a, b) -> a.weight - b.weight);
        key[0] = 0;
        pq.offer(new Node(0, 0));
        
        while (!pq.isEmpty()) {
            int u = pq.poll().vertex;
            inMST[u] = true;
            
            for (Node node : adjList.get(u)) {
                int v = node.vertex;
                int weight = node.weight;
                
                if (!inMST[v] && weight < key[v]) {
                    key[v] = weight;
                    parent[v] = u;
                    pq.offer(new Node(v, key[v]));
                }
            }
        }
        
        printMST(parent, key);
    }
    
    // Kruskal's Algorithm
    public void kruskalMST() {
        Collections.sort(edges);
        DisjointSet ds = new DisjointSet(V);
        List<Edge> result = new ArrayList<>();
        
        for (Edge edge : edges) {
            if (ds.find(edge.src) != ds.find(edge.dest)) {
                result.add(edge);
                ds.union(edge.src, edge.dest);
            }
        }
        
        System.out.println("\nKruskal's MST:");
        int totalWeight = 0;
        for (Edge edge : result) {
            System.out.println(edge.src + " -- " + edge.dest + " == " + edge.weight);
            totalWeight += edge.weight;
        }
        System.out.println("Total MST weight: " + totalWeight);
    }
    
    private void printMST(int[] parent, int[] key) {
        System.out.println("Prim's MST:");
        int totalWeight = 0;
        for (int i = 1; i < V; i++) {
            System.out.println(parent[i] + " -- " + i + " == " + key[i]);
            totalWeight += key[i];
        }
        System.out.println("Total MST weight: " + totalWeight);
    }
    
    private class DisjointSet {
        int[] parent, rank;
        
        DisjointSet(int n) {
            parent = new int[n];
            rank = new int[n];
            for (int i = 0; i < n; i++) {
                parent[i] = i;
            }
        }
        
        int find(int x) {
            if (parent[x] != x) {
                parent[x] = find(parent[x]);
            }
            return parent[x];
        }
        
        void union(int x, int y) {
            int px = find(x), py = find(y);
            if (px == py) return;
            
            if (rank[px] < rank[py]) {
                parent[px] = py;
            } else if (rank[px] > rank[py]) {
                parent[py] = px;
            } else {
                parent[py] = px;
                rank[px]++;
            }
        }
    }
}