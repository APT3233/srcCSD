package recursion;

/**
 * Question: What is binary recursion? Give examples of binary/tail recursions
 * 
 * Examples:
 * 1. Fibonacci sequence (binary recursion)
 * 2. Factorial (tail recursion)
 * 3. Binary search (binary recursion)
 * 4. Sum of array elements (tail recursion)
 */
public class BinaryRecursion {
    // Example 1: Fibonacci sequence (binary recursion)
    public static int fibonacci(int n) {
        if (n <= 1) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
    
    // Example 2: Factorial (tail recursion)
    public static int factorial(int n) {
        return factorialHelper(n, 1);
    }
    
    private static int factorialHelper(int n, int acc) {
        if (n <= 1) return acc;
        return factorialHelper(n - 1, n * acc);
    }
    
    // Example 3: Binary search (binary recursion)
    public static int binarySearch(int[] arr, int target, int left, int right) {
        if (left > right) return -1;
        
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) return mid;
        
        if (arr[mid] > target) {
            return binarySearch(arr, target, left, mid - 1);
        }
        return binarySearch(arr, target, mid + 1, right);
    }
    
    // Example 4: Sum of array elements (tail recursion)
    public static int arraySum(int[] arr) {
        return arraySumHelper(arr, 0, 0);
    }
    
    private static int arraySumHelper(int[] arr, int index, int sum) {
        if (index >= arr.length) return sum;
        return arraySumHelper(arr, index + 1, sum + arr[index]);
    }
    
    public static void main(String[] args) {
        // Test Fibonacci
        System.out.println("Fibonacci(6): " + fibonacci(6)); // 8
        
        // Test Factorial
        System.out.println("Factorial(5): " + factorial(5)); // 120
        
        // Test Binary Search
        int[] arr = {1, 3, 5, 7, 9, 11};
        System.out.println("Binary Search for 7: " + 
            binarySearch(arr, 7, 0, arr.length - 1)); // 3
        
        // Test Array Sum
        int[] numbers = {1, 2, 3, 4, 5};
        System.out.println("Array Sum: " + arraySum(numbers)); // 15
    }
}