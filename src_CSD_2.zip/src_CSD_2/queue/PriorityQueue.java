package queue;

/**
 * Question: Implement a priority queue using linked list
 * Operations:
 * - enqueue with priority
 * - dequeue (highest priority first)
 * - peek
 * - isEmpty
 * 
 * Example usage:
 * PriorityQueue<String> pq = new PriorityQueue<>();
 * pq.enqueue("Task 1", 2);
 * pq.enqueue("Task 2", 1);
 * pq.enqueue("Task 3", 3);
 * pq.dequeue(); // returns "Task 3" (highest priority)
 */
public class PriorityQueue<T> {
    private class Node {
        T data;
        int priority;
        Node next;
        
        Node(T data, int priority) {
            this.data = data;
            this.priority = priority;
            this.next = null;
        }
    }
    
    private Node head;
    
    public void enqueue(T data, int priority) {
        Node newNode = new Node(data, priority);
        
        if (head == null || priority > head.priority) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.priority >= priority) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }
    
    public T dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        T data = head.data;
        head = head.next;
        return data;
    }
    
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return head.data;
    }
    
    public boolean isEmpty() {
        return head == null;
    }
}