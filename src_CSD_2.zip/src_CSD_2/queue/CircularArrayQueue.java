package queue;

/**
 * Question: Implement a queue using circular array
 * Operations:
 * - enqueue
 * - dequeue
 * - peek
 * - isEmpty
 * - isFull
 * 
 * Example usage:
 * CircularArrayQueue<Integer> queue = new CircularArrayQueue<>(5);
 * queue.enqueue(1);
 * queue.enqueue(2);
 * queue.dequeue(); // returns 1
 * queue.peek(); // returns 2
 */
public class CircularArrayQueue<T> {
    private T[] array;
    private int front;
    private int rear;
    private int capacity;
    private int size;
    
    @SuppressWarnings("unchecked")
    public CircularArrayQueue(int capacity) {
        this.capacity = capacity;
        array = (T[]) new Object[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }
    
    public void enqueue(T data) {
        if (isFull()) {
            throw new IllegalStateException("Queue is full");
        }
        rear = (rear + 1) % capacity;
        array[rear] = data;
        size++;
    }
    
    public T dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        T data = array[front];
        front = (front + 1) % capacity;
        size--;
        return data;
    }
    
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return array[front];
    }
    
    public boolean isEmpty() {
        return size == 0;
    }
    
    public boolean isFull() {
        return size == capacity;
    }
}