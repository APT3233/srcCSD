package dynamic;

/**
 * Question: Calculate minimum number of operations required to convert one string to another
 * Operations allowed: Insert, Remove, Replace
 * 
 * Example usage:
 * String str1 = "sunday";
 * String str2 = "saturday";
 * EditDistance.minDistance(str1, str2);
 */
public class EditDistance {
    public static int minDistance(String word1, String word2) {
        int m = word1.length();
        int n = word2.length();
        int[][] dp = new int[m + 1][n + 1];
        
        // Fill dp[][] in bottom up manner
        for (int i = 0; i <= m; i++) {
            for (int j = 0; j <= n; j++) {
                // If first string is empty, only option is to insert all characters of second string
                if (i == 0) {
                    dp[i][j] = j;
                }
                // If second string is empty, only option is to remove all characters of first string
                else if (j == 0) {
                    dp[i][j] = i;
                }
                // If last characters are same, ignore last char and recur for remaining string
                else if (word1.charAt(i - 1) == word2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                }
                // If last characters are different, consider all operations
                else {
                    dp[i][j] = 1 + Math.min(
                        dp[i][j - 1],      // Insert
                        Math.min(
                            dp[i - 1][j],  // Remove
                            dp[i - 1][j - 1] // Replace
                        )
                    );
                }
            }
        }
        
        printOperations(dp, word1, word2);
        return dp[m][n];
    }
    
    private static void printOperations(int[][] dp, String word1, String word2) {
        int i = word1.length();
        int j = word2.length();
        
        System.out.println("Operations needed:");
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && word1.charAt(i - 1) == word2.charAt(j - 1)) {
                i--;
                j--;
            } else if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
                System.out.println("Replace " + word1.charAt(i - 1) + 
                                 " with " + word2.charAt(j - 1));
                i--;
                j--;
            } else if (j > 0 && dp[i][j] == dp[i][j - 1] + 1) {
                System.out.println("Insert " + word2.charAt(j - 1));
                j--;
            } else if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
                System.out.println("Delete " + word1.charAt(i - 1));
                i--;
            }
        }
    }
    
    public static void main(String[] args) {
        String str1 = "sunday";
        String str2 = "saturday";
        
        System.out.println("String 1: " + str1);
        System.out.println("String 2: " + str2);
        System.out.println("Minimum number of operations: " + 
            minDistance(str1, str2));
    }
}