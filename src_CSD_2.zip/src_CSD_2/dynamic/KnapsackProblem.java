package dynamic;

/**
 * Question: Solve the 0/1 Knapsack problem using dynamic programming
 * 
 * Example usage:
 * int[] values = {60, 100, 120};
 * int[] weights = {10, 20, 30};
 * int capacity = 50;
 * KnapsackProblem.solve(values, weights, capacity);
 */
public class KnapsackProblem {
    public static int solve(int[] values, int[] weights, int capacity) {
        int n = values.length;
        int[][] dp = new int[n + 1][capacity + 1];
        
        // Build table dp[][] in bottom-up manner
        for (int i = 0; i <= n; i++) {
            for (int w = 0; w <= capacity; w++) {
                if (i == 0 || w == 0) {
                    dp[i][w] = 0;
                } else if (weights[i - 1] <= w) {
                    dp[i][w] = Math.max(
                        values[i - 1] + dp[i - 1][w - weights[i - 1]],
                        dp[i - 1][w]
                    );
                } else {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }
        
        // Find selected items
        System.out.println("Selected items:");
        int res = dp[n][capacity];
        int w = capacity;
        for (int i = n; i > 0 && res > 0; i--) {
            if (res != dp[i - 1][w]) {
                System.out.println("Item " + i + " (Weight: " + weights[i-1] + 
                                 ", Value: " + values[i-1] + ")");
                res -= values[i - 1];
                w -= weights[i - 1];
            }
        }
        
        return dp[n][capacity];
    }
    
    public static void main(String[] args) {
        int[] values = {60, 100, 120};
        int[] weights = {10, 20, 30};
        int capacity = 50;
        
        System.out.println("Maximum value: " + 
            solve(values, weights, capacity));
    }
}