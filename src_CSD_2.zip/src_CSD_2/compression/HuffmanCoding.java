package compression;

import java.util.PriorityQueue;
import java.util.HashMap;
import java.util.Map;

/**
 * Question: Use binary tree (and priority queue) to encrypt a text file with Huffman's algorithm?
 * 
 * Example usage:
 * String text = "this is an example for huffman encoding";
 * HuffmanCoding huffman = new HuffmanCoding();
 * String encoded = huffman.encode(text);
 * String decoded = huffman.decode(encoded);
 */
public class HuffmanCoding {
    private class Node implements Comparable<Node> {
        char ch;
        int freq;
        Node left, right;
        
        Node(char ch, int freq) {
            this.ch = ch;
            this.freq = freq;
        }
        
        Node(int freq, Node left, Node right) {
            this.freq = freq;
            this.left = left;
            this.right = right;
        }
        
        boolean isLeaf() {
            return left == null && right == null;
        }
        
        @Override
        public int compareTo(Node other) {
            return this.freq - other.freq;
        }
    }
    
    private Node root;
    private Map<Character, String> huffmanCodes;
    
    public String encode(String text) {
        // Build frequency table
        Map<Character, Integer> freq = new HashMap<>();
        for (char c : text.toCharArray()) {
            freq.put(c, freq.getOrDefault(c, 0) + 1);
        }
        
        // Build Huffman tree
        root = buildHuffmanTree(freq);
        
        // Generate Huffman codes
        huffmanCodes = new HashMap<>();
        generateCodes(root, "");
        
        // Encode text
        StringBuilder encoded = new StringBuilder();
        for (char c : text.toCharArray()) {
            encoded.append(huffmanCodes.get(c));
        }
        
        return encoded.toString();
    }
    
    private Node buildHuffmanTree(Map<Character, Integer> freq) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        
        // Create leaf nodes
        for (Map.Entry<Character, Integer> entry : freq.entrySet()) {
            pq.offer(new Node(entry.getKey(), entry.getValue()));
        }
        
        // Build tree by combining nodes
        while (pq.size() > 1) {
            Node left = pq.poll();
            Node right = pq.poll();
            Node parent = new Node(left.freq + right.freq, left, right);
            pq.offer(parent);
        }
        
        return pq.poll();
    }
    
    private void generateCodes(Node node, String code) {
        if (node.isLeaf()) {
            huffmanCodes.put(node.ch, code);
            return;
        }
        
        generateCodes(node.left, code + "0");
        generateCodes(node.right, code + "1");
    }
    
    public String decode(String encoded) {
        StringBuilder decoded = new StringBuilder();
        Node current = root;
        
        for (char bit : encoded.toCharArray()) {
            if (bit == '0') {
                current = current.left;
            } else {
                current = current.right;
            }
            
            if (current.isLeaf()) {
                decoded.append(current.ch);
                current = root;
            }
        }
        
        return decoded.toString();
    }
    
    public static void main(String[] args) {
        String text = "this is an example for huffman encoding";
        HuffmanCoding huffman = new HuffmanCoding();
        
        System.out.println("Original text: " + text);
        
        String encoded = huffman.encode(text);
        System.out.println("Encoded: " + encoded);
        
        String decoded = huffman.decode(encoded);
        System.out.println("Decoded: " + decoded);
        
        // Print Huffman codes
        System.out.println("\nHuffman Codes:");
        for (Map.Entry<Character, String> entry : huffman.huffmanCodes.entrySet()) {
            System.out.println("'" + entry.getKey() + "': " + entry.getValue());
        }
    }
}