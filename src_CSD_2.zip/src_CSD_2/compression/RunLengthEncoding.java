package compression;

/**
 * Question: How to encrypt/decrypt text with Run Length Encoding algorithm?
 * 
 * Example usage:
 * RunLengthEncoding rle = new RunLengthEncoding();
 * String encoded = rle.encode("WWWWWWWWWWWWBWWWWWWWWWWWWBBBWWWWWWWWWWWWWWWWWWB");
 * String decoded = rle.decode(encoded);
 */
public class RunLengthEncoding {
    public String encode(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        
        StringBuilder encoded = new StringBuilder();
        char currentChar = text.charAt(0);
        int count = 1;
        
        for (int i = 1; i < text.length(); i++) {
            if (text.charAt(i) == currentChar) {
                count++;
            } else {
                encoded.append(count).append(currentChar);
                currentChar = text.charAt(i);
                count = 1;
            }
        }
        
        encoded.append(count).append(currentChar);
        return encoded.toString();
    }
    
    public String decode(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        
        StringBuilder decoded = new StringBuilder();
        StringBuilder count = new StringBuilder();
        
        for (char c : text.toCharArray()) {
            if (Character.isDigit(c)) {
                count.append(c);
            } else {
                int repeat = Integer.parseInt(count.toString());
                for (int i = 0; i < repeat; i++) {
                    decoded.append(c);
                }
                count.setLength(0);
            }
        }
        
        return decoded.toString();
    }
    
    public static void main(String[] args) {
        RunLengthEncoding rle = new RunLengthEncoding();
        String text = "WWWWWWWWWWWWBWWWWWWWWWWWWBBBWWWWWWWWWWWWWWWWWWB";
        
        System.out.println("Original text: " + text);
        String encoded = rle.encode(text);
        System.out.println("Encoded: " + encoded);
        String decoded = rle.decode(encoded);
        System.out.println("Decoded: " + decoded);
        System.out.println("Original matches decoded: " + text.equals(decoded));
    }
}